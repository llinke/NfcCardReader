     _  _ ____ _    _    ____    ___ _  _ ____ ____ ____
     |__| |___ |    |    |  |     |  |__| |___ |__/ |___
     |  | |___ |___ |___ |__|     |  |  | |___ |  \ |___

------------------------------------------------------------
     =- M R . F I S K - F O N T -=- P R O D U C T I O N -=
------------------------------------------------------------

     This is the font : DEAD POSTMAN 2004. 
     Made by me : � MR.FISK [MikeLarson]

     Write me when u have installed it on yer computor.
     Use these adresses:
     Email: advert@undergroundstar.com
     fontex2000mg@softhome.net

     Web: www.undergroundstar.com

     Not for commercial use, if you wanna use it for 
     such things - contact me! There is a fee you'll 
     have to pay.

------------------------------------------------------------
     =- M R . F I S K - F O N T -=- P R O D U C T I O N -=
------------------------------------------------------------