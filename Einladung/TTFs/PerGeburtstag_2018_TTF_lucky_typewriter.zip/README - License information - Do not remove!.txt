EN > You�ve just downloaded the LUCKY TYPEWRITER font version 1.0 (12/13/2013).

LUCKY TYPEWRITER font was created by Lukas Krakora and is free for non-commercial use only!

If you want to use the font commercially contact me at my email krraaa@yahoo.com to get the information about pricing.

Please type "LUCKY TYPEWRITER" in subject of your message.

I can add any extra characters or customize the font for holders of the commercial license.

Any donations from non-commercial users to my Paypal krraaa@yahoo.com are welcome. 

Please do not distribute the font and do not upload it to any font web page at your own will. 
But you can link to its original location on Dafont or Fontspace. 

You can find my other fonts on www.typewriterfonts.net 

Thank you.

LK


CZ > Prave jste si stahli font LUCKY TYPEWRITER verze 1.0 (13.12.2013).

Font LUCKY TYPEWRITER byl vytvoren Lukasem Krakorou a je volne ke stazeni a pouziti avsak pouze pro nekomercni ucely!

V pripade zameru vyuzit font komercne me prosim kontaktujte na emailu krraaa@yahoo.com a dozvite se cenu.

Pokud mi budete psat, nezapomente do predmetu zpravy napsat "LUCKY TYPEWRITER".

V pripade potreby mohu drzitelum komercni licence pridat k fontu dalsi znaky, ci jakkoli upravit existujici.

Jakekoliv financni prispevky od nekomercnich uzivatelu na muj Paypal krraaa@yahoo.com jsou vitany.

Font prosim dale nedistribujte a nezavesujte ho na zadne stranky z vlastniho uvazeni. 
Muzete vsak svobodne odkazovat na jeho puvodni umisteni na Dafontu nebo Fontspace.

Me dalsi fonty naleznete na www.typewriterfonts.net

Diky.

LK
